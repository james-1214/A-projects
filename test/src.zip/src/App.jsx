import React from "react";
import AuthPages from "./components/AuthPages";

function App() {
  return (
    <div>
      <AuthPages />
    </div>
  );
}

export default App;
